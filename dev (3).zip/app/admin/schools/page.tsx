"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Plus, Search, Filter, Eye, Edit2, MoreVertical, MapPin, Users, Phone, Mail, User, School as SchoolIcon } from "lucide-react"
import { adminSchools } from "@/lib/data/admin-dummy-data"
import type { School } from "@/lib/data/admin-dummy-data"
import { useSound } from "@/lib/sound-provider"

export default function AdminSchoolsPage() {
  const { playSound } = useSound()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedDistrict, setSelectedDistrict] = useState("all")
  const [selectedSchool, setSelectedSchool] = useState<School | null>(null)
  const [showDetailModal, setShowDetailModal] = useState(false)

  const filteredSchools = adminSchools.filter((school) => {
    const matchesSearch =
      school.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      school.address.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesDistrict = selectedDistrict === "all" || school.district === selectedDistrict
    return matchesSearch && matchesDistrict
  })

  const districts = ["all", ...Array.from(new Set(adminSchools.map((s) => s.district)))]

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Schools Management</h1>
            <p className="text-muted-foreground mt-1">Manage enrolled schools and their information</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => playSound("click")}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold shadow-lg hover:shadow-xl transition-all flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add School
          </motion.button>
        </div>

        {/* Filters */}
        <div className="bg-background/80 backdrop-blur-xl rounded-2xl border border-border/50 p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search schools..."
                className="w-full pl-11 pr-4 py-3 rounded-xl bg-muted/50 border border-border/50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                onFocus={() => playSound("hover")}
              />
            </div>

            {/* District Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <select
                value={selectedDistrict}
                onChange={(e) => {
                  playSound("click")
                  setSelectedDistrict(e.target.value)
                }}
                className="w-full pl-11 pr-4 py-3 rounded-xl bg-muted/50 border border-border/50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all appearance-none"
              >
                {districts.map((district) => (
                  <option key={district} value={district}>
                    {district === "all" ? "All Districts" : district}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Schools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSchools.map((school, index) => (
            <motion.div
              key={school.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-background/80 backdrop-blur-xl rounded-2xl border border-border/50 overflow-hidden hover:shadow-xl transition-all group"
            >
              {/* School Logo */}
              <div className="h-32 bg-gradient-to-br from-blue-100 to-indigo-100 dark:from-blue-950/50 dark:to-indigo-950/50 flex items-center justify-center relative">
                <SchoolIcon className="w-16 h-16 text-blue-500/30" />
                <div
                  className={`absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-semibold ${
                    school.status === "active"
                      ? "bg-green-500/20 text-green-700 dark:text-green-400"
                      : school.status === "suspended"
                        ? "bg-red-500/20 text-red-700 dark:text-red-400"
                        : "bg-gray-500/20 text-gray-700 dark:text-gray-400"
                  }`}
                >
                  {school.status}
                </div>
              </div>

              {/* School Info */}
              <div className="p-6">
                <h3 className="font-bold text-lg text-foreground mb-2">{school.name}</h3>

                <div className="space-y-2 mb-4">
                  <div className="flex items-start gap-2 text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span className="line-clamp-2">{school.address}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="w-4 h-4 flex-shrink-0" />
                    <span>{school.studentCount} students</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      playSound("click")
                      setSelectedSchool(school)
                      setShowDetailModal(true)
                    }}
                    className="flex-1 px-4 py-2 rounded-lg bg-blue-500 text-white font-medium text-sm hover:bg-blue-600 transition-colors flex items-center justify-center gap-2"
                  >
                    <Eye className="w-4 h-4" />
                    View Details
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => playSound("click")}
                    className="px-3 py-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
                  >
                    <MoreVertical className="w-4 h-4 text-muted-foreground" />
                  </motion.button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Detail Modal */}
        {showDetailModal && selectedSchool && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowDetailModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-background rounded-2xl border border-border/50 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 border-b border-border/50">
                <h2 className="text-2xl font-bold text-foreground">{selectedSchool.name}</h2>
                <p className="text-sm text-muted-foreground mt-1">School ID: {selectedSchool.id}</p>
              </div>

              <div className="p-6 space-y-6">
                {/* Basic Info */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Basic Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">District</p>
                      <p className="text-sm font-medium text-foreground">{selectedSchool.district}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Student Count</p>
                      <p className="text-sm font-medium text-foreground">{selectedSchool.studentCount}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Status</p>
                      <span
                        className={`inline-block px-2 py-1 rounded-full text-xs font-semibold ${
                          selectedSchool.status === "active"
                            ? "bg-green-500/20 text-green-700 dark:text-green-400"
                            : "bg-red-500/20 text-red-700 dark:text-red-400"
                        }`}
                      >
                        {selectedSchool.status}
                      </span>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Enrollment Date</p>
                      <p className="text-sm font-medium text-foreground">{selectedSchool.enrollmentDate}</p>
                    </div>
                  </div>
                </div>

                {/* Location */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Location</h3>
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                    <p className="text-sm text-foreground">{selectedSchool.address}</p>
                  </div>
                </div>

                {/* Principal Info */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Principal Contact</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <p className="text-sm text-foreground">{selectedSchool.principalName}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-muted-foreground" />
                      <p className="text-sm text-foreground">{selectedSchool.principalEmail}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-muted-foreground" />
                      <p className="text-sm text-foreground">{selectedSchool.principalPhone}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-border/50 flex justify-end gap-3">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowDetailModal(false)}
                  className="px-6 py-2 rounded-lg border border-border hover:bg-muted transition-colors font-medium text-sm"
                >
                  Close
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => playSound("click")}
                  className="px-6 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors font-medium text-sm flex items-center gap-2"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit School
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </motion.div>
  )
}
