package main

import (
	"fmt"
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"mbg-api/internal/database"
	"mbg-api/internal/handlers"
	"mbg-api/internal/middleware"
	"mbg-api/internal/models"
)

func init() {
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, using environment variables")
	}
}

func main() {
	// Initialize database
	db, err := database.InitDB()
	if err != nil {
		log.Fatalf("Failed to initialize database: %v", err)
	}

	// Run migrations
	if err := db.AutoMigrate(
		&models.User{},
		&models.School{},
		&models.Meal{},
		&models.MealPlan{},
		&models.Supplier{},
		&models.Order{},
		&models.Student{},
		&models.Announcement{},
	); err != nil {
		log.Fatalf("Failed to run migrations: %v", err)
	}

	// Initialize Gin router
	router := gin.Default()

	// Middleware
	router.Use(middleware.CORSMiddleware())
	router.Use(middleware.LoggingMiddleware())

	// Health check
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	// API v1 routes
	v1 := router.Group("/api/v1")
	{
		// Auth routes
		auth := v1.Group("/auth")
		{
			auth.POST("/register", handlers.NewAuthHandler(db).Register)
			auth.POST("/login", handlers.NewAuthHandler(db).Login)
			auth.POST("/logout", middleware.AuthMiddleware(), handlers.NewAuthHandler(db).Logout)
			auth.POST("/refresh", handlers.NewAuthHandler(db).RefreshToken)
		}

		// User routes
		users := v1.Group("/users")
		users.Use(middleware.AuthMiddleware())
		{
			usersHandler := handlers.NewUserHandler(db)
			users.GET("/:id", usersHandler.GetUser)
			users.PUT("/:id", usersHandler.UpdateUser)
			users.DELETE("/:id", usersHandler.DeleteUser)
			users.GET("", usersHandler.ListUsers)
		}

		// School routes (Admin only)
		schools := v1.Group("/schools")
		schools.Use(middleware.AuthMiddleware(), middleware.AdminMiddleware())
		{
			schoolsHandler := handlers.NewSchoolHandler(db)
			schools.POST("", schoolsHandler.CreateSchool)
			schools.GET("/:id", schoolsHandler.GetSchool)
			schools.PUT("/:id", schoolsHandler.UpdateSchool)
			schools.DELETE("/:id", schoolsHandler.DeleteSchool)
			schools.GET("", schoolsHandler.ListSchools)
		}

		// Meals routes
		meals := v1.Group("/meals")
		meals.Use(middleware.AuthMiddleware())
		{
			mealsHandler := handlers.NewMealHandler(db)
			meals.POST("", middleware.AdminMiddleware(), mealsHandler.CreateMeal)
			meals.GET("/:id", mealsHandler.GetMeal)
			meals.PUT("/:id", middleware.AdminMiddleware(), mealsHandler.UpdateMeal)
			meals.DELETE("/:id", middleware.AdminMiddleware(), mealsHandler.DeleteMeal)
			meals.GET("", mealsHandler.ListMeals)
		}

		// Suppliers routes
		suppliers := v1.Group("/suppliers")
		suppliers.Use(middleware.AuthMiddleware())
		{
			suppliersHandler := handlers.NewSupplierHandler(db)
			suppliers.POST("", middleware.AdminMiddleware(), suppliersHandler.CreateSupplier)
			suppliers.GET("/:id", suppliersHandler.GetSupplier)
			suppliers.PUT("/:id", suppliersHandler.UpdateSupplier)
			suppliers.DELETE("/:id", middleware.AdminMiddleware(), suppliersHandler.DeleteSupplier)
			suppliers.GET("", suppliersHandler.ListSuppliers)
		}

		// Orders routes
		orders := v1.Group("/orders")
		orders.Use(middleware.AuthMiddleware())
		{
			ordersHandler := handlers.NewOrderHandler(db)
			orders.POST("", ordersHandler.CreateOrder)
			orders.GET("/:id", ordersHandler.GetOrder)
			orders.PUT("/:id", ordersHandler.UpdateOrder)
			orders.DELETE("/:id", ordersHandler.DeleteOrder)
			orders.GET("", ordersHandler.ListOrders)
		}

		// Students routes
		students := v1.Group("/students")
		students.Use(middleware.AuthMiddleware())
		{
			studentsHandler := handlers.NewStudentHandler(db)
			students.POST("", studentsHandler.CreateStudent)
			students.GET("/:id", studentsHandler.GetStudent)
			students.PUT("/:id", studentsHandler.UpdateStudent)
			students.DELETE("/:id", studentsHandler.DeleteStudent)
			students.GET("", studentsHandler.ListStudents)
		}

		// Announcements routes
		announcements := v1.Group("/announcements")
		announcements.Use(middleware.AuthMiddleware())
		{
			announcementsHandler := handlers.NewAnnouncementHandler(db)
			announcements.POST("", middleware.AdminMiddleware(), announcementsHandler.CreateAnnouncement)
			announcements.GET("/:id", announcementsHandler.GetAnnouncement)
			announcements.PUT("/:id", middleware.AdminMiddleware(), announcementsHandler.UpdateAnnouncement)
			announcements.DELETE("/:id", middleware.AdminMiddleware(), announcementsHandler.DeleteAnnouncement)
			announcements.GET("", announcementsHandler.ListAnnouncements)
		}
	}

	// Start server
	port := os.Getenv("PORT")
	if port == "" {
		port = "8000"
	}

	fmt.Printf("🚀 MBG API Server running on http://localhost:%s\n", port)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}
