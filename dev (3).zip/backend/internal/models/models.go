package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// User represents a user in the system
type User struct {
	ID            string    `gorm:"primaryKey" json:"id"`
	FirstName     string    `json:"first_name"`
	LastName      string    `json:"last_name"`
	Email         string    `gorm:"uniqueIndex" json:"email"`
	Phone         string    `json:"phone"`
	Password      string    `json:"-"` // Never expose password
	Role          string    `json:"role"` // admin, parent, supplier
	Address       string    `json:"address"`
	SchoolID      *string   `json:"school_id,omitempty"`
	IsActive      bool      `json:"is_active"`
	LastLoginAt   *time.Time `json:"last_login_at,omitempty"`
	CreatedAt     time.Time `json:"created_at"`
	UpdatedAt     time.Time `json:"updated_at"`
	DeletedAt     gorm.DeletedAt `gorm:"index" json:"deleted_at,omitempty"`
}

// BeforeCreate generates UUID before creating a user
func (u *User) BeforeCreate(tx *gorm.DB) error {
	if u.ID == "" {
		u.ID = uuid.New().String()
	}
	return nil
}

// School represents a school
type School struct {
	ID            string    `gorm:"primaryKey" json:"id"`
	Name          string    `json:"name"`
	Address       string    `json:"address"`
	Phone         string    `json:"phone"`
	Email         string    `json:"email"`
	Principal     string    `json:"principal"`
	StudentsCount int       `json:"students_count"`
	CreatedAt     time.Time `json:"created_at"`
	UpdatedAt     time.Time `json:"updated_at"`
	DeletedAt     gorm.DeletedAt `gorm:"index" json:"deleted_at,omitempty"`
}

func (s *School) BeforeCreate(tx *gorm.DB) error {
	if s.ID == "" {
		s.ID = uuid.New().String()
	}
	return nil
}

// Meal represents a meal
type Meal struct {
	ID            string    `gorm:"primaryKey" json:"id"`
	Name          string    `json:"name"`
	Description   string    `json:"description"`
	Calories      int       `json:"calories"`
	Protein       float64   `json:"protein"`
	Carbs         float64   `json:"carbs"`
	Fat           float64   `json:"fat"`
	Allergens     string    `json:"allergens"`
	SchoolID      string    `json:"school_id"`
	School        *School   `json:"school,omitempty" gorm:"foreignKey:SchoolID"`
	CreatedAt     time.Time `json:"created_at"`
	UpdatedAt     time.Time `json:"updated_at"`
	DeletedAt     gorm.DeletedAt `gorm:"index" json:"deleted_at,omitempty"`
}

func (m *Meal) BeforeCreate(tx *gorm.DB) error {
	if m.ID == "" {
		m.ID = uuid.New().String()
	}
	return nil
}

// MealPlan represents a meal plan assigned to a student
type MealPlan struct {
	ID        string    `gorm:"primaryKey" json:"id"`
	StudentID string    `json:"student_id"`
	MealID    string    `json:"meal_id"`
	StartDate time.Time `json:"start_date"`
	EndDate   time.Time `json:"end_date"`
	Meal      *Meal     `json:"meal,omitempty" gorm:"foreignKey:MealID"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"deleted_at,omitempty"`
}

func (mp *MealPlan) BeforeCreate(tx *gorm.DB) error {
	if mp.ID == "" {
		mp.ID = uuid.New().String()
	}
	return nil
}

// Supplier represents a supplier
type Supplier struct {
	ID               string    `gorm:"primaryKey" json:"id"`
	Name             string    `json:"name"`
	Email            string    `gorm:"uniqueIndex" json:"email"`
	Phone            string    `json:"phone"`
	Address          string    `json:"address"`
	ContactPerson    string    `json:"contact_person"`
	UserID           string    `json:"user_id"`
	User             *User     `json:"user,omitempty" gorm:"foreignKey:UserID"`
	Rating           float64   `json:"rating"`
	IsActive         bool      `json:"is_active"`
	CreatedAt        time.Time `json:"created_at"`
	UpdatedAt        time.Time `json:"updated_at"`
	DeletedAt        gorm.DeletedAt `gorm:"index" json:"deleted_at,omitempty"`
}

func (s *Supplier) BeforeCreate(tx *gorm.DB) error {
	if s.ID == "" {
		s.ID = uuid.New().String()
	}
	return nil
}

// Order represents an order from a supplier
type Order struct {
	ID          string    `gorm:"primaryKey" json:"id"`
	SupplierID  string    `json:"supplier_id"`
	Supplier    *Supplier `json:"supplier,omitempty" gorm:"foreignKey:SupplierID"`
	SchoolID    string    `json:"school_id"`
	School      *School   `json:"school,omitempty" gorm:"foreignKey:SchoolID"`
	Status      string    `json:"status"` // pending, confirmed, delivered, cancelled
	TotalAmount float64   `json:"total_amount"`
	OrderDate   time.Time `json:"order_date"`
	DeliveryDate *time.Time `json:"delivery_date,omitempty"`
	Notes       string    `json:"notes"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
	DeletedAt   gorm.DeletedAt `gorm:"index" json:"deleted_at,omitempty"`
}

func (o *Order) BeforeCreate(tx *gorm.DB) error {
	if o.ID == "" {
		o.ID = uuid.New().String()
	}
	return nil
}

// Student represents a student
type Student struct {
	ID           string    `gorm:"primaryKey" json:"id"`
	FirstName    string    `json:"first_name"`
	LastName     string    `json:"last_name"`
	SchoolID     string    `json:"school_id"`
	School       *School   `json:"school,omitempty" gorm:"foreignKey:SchoolID"`
	ParentID     string    `json:"parent_id"`
	Parent       *User     `json:"parent,omitempty" gorm:"foreignKey:ParentID"`
	DateOfBirth  time.Time `json:"date_of_birth"`
	Grade        string    `json:"grade"`
	Allergies    string    `json:"allergies"`
	DietaryNeeds string    `json:"dietary_needs"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
	DeletedAt    gorm.DeletedAt `gorm:"index" json:"deleted_at,omitempty"`
}

func (s *Student) BeforeCreate(tx *gorm.DB) error {
	if s.ID == "" {
		s.ID = uuid.New().String()
	}
	return nil
}

// Announcement represents an announcement
type Announcement struct {
	ID        string    `gorm:"primaryKey" json:"id"`
	Title     string    `json:"title"`
	Content   string    `json:"content"`
	SchoolID  string    `json:"school_id"`
	School    *School   `json:"school,omitempty" gorm:"foreignKey:SchoolID"`
	CreatedBy string    `json:"created_by"`
	Creator   *User     `json:"creator,omitempty" gorm:"foreignKey:CreatedBy"`
	IsActive  bool      `json:"is_active"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"deleted_at,omitempty"`
}

func (a *Announcement) BeforeCreate(tx *gorm.DB) error {
	if a.ID == "" {
		a.ID = uuid.New().String()
	}
	return nil
}
