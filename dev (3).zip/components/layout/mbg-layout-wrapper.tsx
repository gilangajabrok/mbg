"use client"

import { usePathname } from "next/navigation"
import type { ReactNode } from "react"
import { MBGLayout } from "./mbg-layout"

export function MBGLayoutWrapper({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  // If pathname is not ready yet (during initial render/hydration), avoid applying MBGLayout
  if (!pathname) return <>{children}</>

  // Normalize pathname (strip query/hash and trailing slashes)
  const normalized = pathname.split("?")[0].split("#")[0].replace(/\/+$/, "")

  // Robust role-route detection: matches /admin, /supplier, /parent and their child routes
  const roleRouteRegex = /^\/(admin|supplier|parent)(?:\/|$)/i
  const authRouteRegex = /^(?:\/login|\/auth|\/forgot-password|\/2fa|\/register)(?:\/|$)/i

  if (roleRouteRegex.test(normalized) || authRouteRegex.test(normalized)) {
    return <>{children}</>
  }

  // For all other routes, use the default MBGLayout
  return <MBGLayout>{children}</MBGLayout>
}
